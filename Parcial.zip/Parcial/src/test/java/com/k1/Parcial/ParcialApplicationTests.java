package com.k1.Parcial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParcialApplicationTests {

	@Test
	void contextLoads() {
	}

}
